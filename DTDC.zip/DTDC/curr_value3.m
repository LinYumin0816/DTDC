function F = curr_value3(G,U,L,R,T,T_r,lambda,mu,beta)
F = nnz(round(R,6)); 
end